/*Cria constante com a sua Key API */
const key = 'c813b1d6ffa4eaa3b0894d8b4aa69770' 
const botao = document.querySelector('.botao-busca')
const titulo = document.querySelector('.cidade')
const temperatura = document.querySelector('.temp')
const imagem = document.querySelector('.img-previsao')
const descricao = document.querySelector('.texto-previsao')
const umidade = document.querySelector('.umidade')


botao.addEventListener('click',clickBotao)
/*funcão para receber o que vem do formulário*/
/*captura o que foi digitado*/
function clickBotao(){
    /*para pegar o que está dentro da caixa*/
    const cidade = document.querySelector('.input-cidade').value
    /*função buscar cidade*/
    buscarCidade(cidade)

}
/*passagem de variavel*/
/*funcão que demora de trazer resposta não pode ser function*/
/*acessando back end: função assincrona = async*/
/*só executa quando recebre uma resposta*/

// segunda parte
async function buscarCidade(cidade){
    /*fetch: para receber algo da API*/
    /*esperar que o fetch ocorra: await*/
    /*Colocar crase para adicionar variaveis suas*/
    /*mandando pra API minha cidade e chave*/
    /*avisar a url: armazene a reposta no arquivo json*/
    /*cria uma variavel do nome que tu quiser*/
    /*prometa que depois de rodar me traga um arquivo json*/
    /*colocar 2 parametros: para portugues e para celcius no final e dentro da url*/
    /*coloca:&lang=pt_br&units=metric*/
const dados = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${cidade}&appid=${key}&lang=pt_br&units=metric`).then(resposta => resposta.json())
console.log(dados)

mostraNaTela(dados)
 //terceira parte
}

function mostraNaTela(dados){
    //imprimindo na tela pegando a variavel que recebe os dados com a variavel que pega o nome da cidade
        titulo.innerHTML = "Tempo em: "+dados.name
        //imprimindo na tela pegando a variavel que recebe os dados com a variavel que pega a temperatura
        //Math ceil aredonda pra baixo o valor da temperatura
        temperatura.innerHTML = Math.ceil(dados.main.temp) +"°C"
        //alterando o src da imagem da api
        imagem.src=`https://openweathermap.org/img/wn/${dados.weather[0].icon}.png` 
        descricao.innerHTML = dados.weather[0].description
        umidade.innerHTML = "Umidade: "+dados.main.humidity+ "%"
   
}